<html>
<head>
<title>Rute Kota Bogor</title>
<!--tempat kode google map-->
<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyCUn6Q6sg0JVJBlgiz4tL2kF1zmVoC0ScE&sensor=true"></script>
<script type="text/javascript" src="<?php echo base_url('files/js/jquery-1.9.1.min.js');?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('files/css/styleku.css');?>">
</head>
<body>
<div id="header">
  <h1><strong>SISTEM INFORMASI GEOGRAFIS</strong><br/><small>TEMPAT-TEMPAT STRATEGIS KOTA BOGOR</small></h1>
</div>